int doubleIt(int a);
