#include "dit.h"

int doubleIt(int a) {
  return a*2;
  // return a<<1;
}
